/***************************************************************/
/* Program repeatedly gets a plain text character typed on the */
/* terminal keyboard and echoes it to the screen.              */
/* If the character is "C," "c," "N," "n," "V," "v," "Z," or   */
/* "z," the full name and explanation of that APSR condition   */
/* flag is displayed on a separate line.                       */
/* These messages are displayed via subroutines.               */
/* (The subroutines are provided in a library.)                */
/*   C or c:  Carry:  set if there was a carry out of or no    */
/*                    borrow into the msb.                     */
/*   N or n:  Negative:  set if result is negative for signed  */
/*                       number; N = msb.                      */
/*   V or v:  Overflow:  set if result is invalid for signed   */
/*                       number.                               */
/*   Z or z:  Zero:  set if result is zero.                    */
/*                                                             */
/* Init_UART0_Polling, GetChar, and PutChar functions are      */
/* written for this exercise and tested with the program       */
/* functionality.                                              */
/*                                                             */
/* Name:  R. W. Melton                                         */
/* Date:  February 22, 2021                                    */
/* Class:  CMPE-250                                            */
/* Section:  All sections                                      */
/***************************************************************/
#include <MKL05Z4.h>
#include "Exercise05_Lib.h"
#include "UART0_Polling.h"

/* Boolean values */
#define FALSE (0)
#define TRUE (1)

int main (void) {
  char Character;

  __asm ("CPSID I");
  Init_UART0_Polling ();
  PutPrompt ();
  do {
    PutChar (Character = GetChar ());
    if ((Character >= 'a') && (Character <= 'z')) {
      Character = Character - ('a' - 'A');
    }
    switch (Character) {
      case 'C': {
        Carry ();
        PutPrompt ();
        break;
      } /* case 'C' */
      case 'N': {
        Negative ();
        PutPrompt ();
        break;
      } /* case 'N' */
      case 'V': {
        Overflow ();
        PutPrompt ();
        break;
      } /* case 'V' */
      case 'Z': {
        Zero ();
        PutPrompt ();
        break;
      } /* case 'V' */
      case '\r': {
        PutChar ('\n');
        PutPrompt ();
      } /* case '\r' */
    }
  } while (TRUE);
}
