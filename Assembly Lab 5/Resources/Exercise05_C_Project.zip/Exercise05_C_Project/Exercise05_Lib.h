/***************************************************************/
/* Definitions to support Exercise05_Lib library.              */
/* R. W. Melton                                                */
/* 2/22/2021                                                   */
/***************************************************************/

void Carry (void);
void Negative (void);
void Overflow (void);
void PutPrompt (void);
void Zero (void);
