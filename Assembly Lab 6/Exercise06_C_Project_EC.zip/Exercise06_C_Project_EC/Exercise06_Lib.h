/***************************************************************/
/* Prototype for Exercise 06 library module                    */
/* R. W. Melton                                                */
/* 10/2/2017                                                   */
/***************************************************************/

uint32_t LengthStringSB (char *String, uint32_t Capacity);
